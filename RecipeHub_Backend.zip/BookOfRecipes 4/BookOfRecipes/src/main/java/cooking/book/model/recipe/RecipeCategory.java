package cooking.book.model.recipe;

public enum RecipeCategory {
    STARTER, MAIN_COURSE, DESSERT;
}
